/** \file
 * hotg-rune-native v0.0.0
 *
 * Authors: The Rune Developers <developers@hotg.ai>
 * License: MIT OR Apache 2.0
 * Commit: c4143204798dfecd18f0b9d3565aed9beb445092
 * Compiler: rustc 1.57.0-nightly (e1e9319d9 2021-10-14)
 * Target: x86_64-unknown-linux-gnu
 * Enabled Features: 
 *
 * Native bindings to the `rune` project.
 */


#ifndef _RUST_RUNE_NATIVE_
#define _RUST_RUNE_NATIVE_

#ifdef __cplusplus
extern "C" {
#endif


#include <stddef.h>
#include <stdint.h>

typedef struct IntegerOrErrorResult IntegerOrErrorResult_t;

/** \brief
 * Create a new `IntegerOrErrorResult` containing the success value.
 */
IntegerOrErrorResult_t * rune_result_IntegerOrErrorResult_new_ok (
    size_t value);

typedef struct Error Error_t;

/** \brief
 * Create a new `IntegerOrErrorResult` containing the error value.
 */
IntegerOrErrorResult_t * rune_result_IntegerOrErrorResult_new_err (
    Error_t * error);


#include <stdbool.h>

/** \brief
 * Check if the result contains a `usize`.
 */
bool rune_result_IntegerOrErrorResult_is_ok (
    IntegerOrErrorResult_t const * result);

/** \brief
 * Check if the result contains a `BoxedError`.
 */
bool rune_result_IntegerOrErrorResult_is_err (
    IntegerOrErrorResult_t const * result);

/** \brief
 * Free the `IntegerOrErrorResult` after you are done with it.
 */
void rune_result_IntegerOrErrorResult_free (
    IntegerOrErrorResult_t * result);

/** \brief
 * Get a reference to the `usize` in this `IntegerOrErrorResult`, or `null` if not present.
 */
size_t const * rune_result_IntegerOrErrorResult_get_ok (
    IntegerOrErrorResult_t const * result);

/** \brief
 * Get a reference to the `BoxedError` in this `IntegerOrErrorResult`, or `null` if not present.
 */
Error_t * const * rune_result_IntegerOrErrorResult_get_err (
    IntegerOrErrorResult_t const * result);

/** \brief
 * Extract the `usize`, freeing the `IntegerOrErrorResult` and crashing if it actually contains a `BoxedError`.
 */
size_t rune_result_IntegerOrErrorResult_take_ok (
    IntegerOrErrorResult_t * result);

/** \brief
 * Extract the `BoxedError`, freeing the `IntegerOrErrorResult` and crashing if it actually contains a `usize`.
 */
Error_t * rune_result_IntegerOrErrorResult_take_err (
    IntegerOrErrorResult_t * result);

/** \brief
 *  Like [`slice_ref`] and [`slice_mut`], but with any lifetime attached
 *  whatsoever.
 * 
 *  It is only intended to be used as the parameter of a **callback** that
 *  locally borrows it, due to limitations of the [`ReprC`][
 *  `trait@crate::layout::ReprC`] design _w.r.t._ higher-rank trait bounds.
 * 
 *  # C layout (for some given type T)
 * 
 *  ```c
 *  typedef struct {
 *      // Cannot be NULL
 *      T * ptr;
 *      size_t len;
 *  } slice_T;
 *  ```
 * 
 *  # Nullable pointer?
 * 
 *  If you want to support the above typedef, but where the `ptr` field is
 *  allowed to be `NULL` (with the contents of `len` then being undefined)
 *  use the `Option< slice_ptr<_> >` type.
 */
typedef struct {

    uint8_t * ptr;

    size_t len;

} slice_raw_uint8_t;

/** \brief
 *  An object which can be used to generate data.
 * 
 *  # Safety
 * 
 *  It is the implementor's responsibility to ensure this type is thread-safe.
 */
typedef struct {

    void * user_data;

    void (*set_parameter)(void *);

    IntegerOrErrorResult_t * (*generate)(void *, slice_raw_uint8_t);

    void (*free)(void *);

} Capability_t;

typedef struct CapabilityResult CapabilityResult_t;

/** \brief
 * Create a new `CapabilityResult` containing the success value.
 */
CapabilityResult_t * rune_result_CapabilityResult_new_ok (
    Capability_t value);

/** \brief
 * Create a new `CapabilityResult` containing the error value.
 */
CapabilityResult_t * rune_result_CapabilityResult_new_err (
    Error_t * error);

/** \brief
 * Check if the result contains a `Capability`.
 */
bool rune_result_CapabilityResult_is_ok (
    CapabilityResult_t const * result);

/** \brief
 * Check if the result contains a `BoxedError`.
 */
bool rune_result_CapabilityResult_is_err (
    CapabilityResult_t const * result);

/** \brief
 * Free the `CapabilityResult` after you are done with it.
 */
void rune_result_CapabilityResult_free (
    CapabilityResult_t * result);

/** \brief
 * Get a reference to the `Capability` in this `CapabilityResult`, or `null` if not present.
 */
Capability_t const * rune_result_CapabilityResult_get_ok (
    CapabilityResult_t const * result);

/** \brief
 * Get a reference to the `BoxedError` in this `CapabilityResult`, or `null` if not present.
 */
Error_t * const * rune_result_CapabilityResult_get_err (
    CapabilityResult_t const * result);

/** \brief
 * Extract the `Capability`, freeing the `CapabilityResult` and crashing if it actually contains a `BoxedError`.
 */
Capability_t rune_result_CapabilityResult_take_ok (
    CapabilityResult_t * result);

/** \brief
 * Extract the `BoxedError`, freeing the `CapabilityResult` and crashing if it actually contains a `Capability`.
 */
Error_t * rune_result_CapabilityResult_take_err (
    CapabilityResult_t * result);

/** \brief
 *  Like [`slice_ref`] and [`slice_mut`], but with any lifetime attached
 *  whatsoever.
 * 
 *  It is only intended to be used as the parameter of a **callback** that
 *  locally borrows it, due to limitations of the [`ReprC`][
 *  `trait@crate::layout::ReprC`] design _w.r.t._ higher-rank trait bounds.
 * 
 *  # C layout (for some given type T)
 * 
 *  ```c
 *  typedef struct {
 *      // Cannot be NULL
 *      T * ptr;
 *      size_t len;
 *  } slice_T;
 *  ```
 * 
 *  # Nullable pointer?
 * 
 *  If you want to support the above typedef, but where the `ptr` field is
 *  allowed to be `NULL` (with the contents of `len` then being undefined)
 *  use the `Option< slice_ptr<_> >` type.
 */
typedef struct {

    slice_raw_uint8_t * ptr;

    size_t len;

} slice_raw_slice_raw_uint8_t;

/** \brief
 *  Like [`slice_ref`] and [`slice_mut`], but with any lifetime attached
 *  whatsoever.
 * 
 *  It is only intended to be used as the parameter of a **callback** that
 *  locally borrows it, due to limitations of the [`ReprC`][
 *  `trait@crate::layout::ReprC`] design _w.r.t._ higher-rank trait bounds.
 * 
 *  # C layout (for some given type T)
 * 
 *  ```c
 *  typedef struct {
 *      // Cannot be NULL
 *      T * ptr;
 *      size_t len;
 *  } slice_T;
 *  ```
 * 
 *  # Nullable pointer?
 * 
 *  If you want to support the above typedef, but where the `ptr` field is
 *  allowed to be `NULL` (with the contents of `len` then being undefined)
 *  use the `Option< slice_ptr<_> >` type.
 */
typedef struct {

    char const * * ptr;

    size_t len;

} slice_raw_char_const_ptr_t;

/** \brief
 *  An object which can do model inference.
 * 
 *  # Safety
 * 
 *  It is the implementor's responsibility to ensure this type is thread-safe.
 */
typedef struct {

    void * user_data;

    IntegerOrErrorResult_t * (*generate)(void *, slice_raw_slice_raw_uint8_t, slice_raw_slice_raw_uint8_t);

    slice_raw_char_const_ptr_t (*inputs)(void *);

    slice_raw_char_const_ptr_t (*outputs)(void *);

    void (*free)(void *);

} Model_t;

typedef struct ModelResult ModelResult_t;

/** \brief
 * Create a new `ModelResult` containing the success value.
 */
ModelResult_t * rune_result_ModelResult_new_ok (
    Model_t value);

/** \brief
 * Create a new `ModelResult` containing the error value.
 */
ModelResult_t * rune_result_ModelResult_new_err (
    Error_t * error);

/** \brief
 * Check if the result contains a `Model`.
 */
bool rune_result_ModelResult_is_ok (
    ModelResult_t const * result);

/** \brief
 * Check if the result contains a `BoxedError`.
 */
bool rune_result_ModelResult_is_err (
    ModelResult_t const * result);

/** \brief
 * Free the `ModelResult` after you are done with it.
 */
void rune_result_ModelResult_free (
    ModelResult_t * result);

/** \brief
 * Get a reference to the `Model` in this `ModelResult`, or `null` if not present.
 */
Model_t const * rune_result_ModelResult_get_ok (
    ModelResult_t const * result);

/** \brief
 * Get a reference to the `BoxedError` in this `ModelResult`, or `null` if not present.
 */
Error_t * const * rune_result_ModelResult_get_err (
    ModelResult_t const * result);

/** \brief
 * Extract the `Model`, freeing the `ModelResult` and crashing if it actually contains a `BoxedError`.
 */
Model_t rune_result_ModelResult_take_ok (
    ModelResult_t * result);

/** \brief
 * Extract the `BoxedError`, freeing the `ModelResult` and crashing if it actually contains a `Model`.
 */
Error_t * rune_result_ModelResult_take_err (
    ModelResult_t * result);

typedef struct RunicosBaseImage RunicosBaseImage_t;

/** \brief
 *  Create a vtable containing the various host functions to be provided to the
 *  Rune.
 * 
 *  Each host function is a closure which may contain its own state.
 * 
 *  On Linux and MacOS, interence is performed using the `tflite` crate
 *  (bindings to TensorFlow Lite). Other platforms will need to specify the
 *  model factory manually (see `rune_image_register_model_handler()`).
 */
RunicosBaseImage_t * rune_image_new (void);

void rune_image_free (
    RunicosBaseImage_t * image);

typedef struct RuneResult RuneResult_t;

/** \remark Has the same ABI as `uint32_t` **/
#ifdef DOXYGEN
typedef enum LogLevel
#else
typedef uint32_t LogLevel_t; enum
#endif
{
    /** \brief
     *  The "error" level.
     * 
     *  Designates very serious errors.
     */
    LOG_LEVEL_ERROR = 1,
    /** \brief
     *  The "warn" level.
     * 
     *  Designates hazardous situations.
     */
    LOG_LEVEL_WARN,
    /** \brief
     *  The "info" level.
     * 
     *  Designates useful information.
     */
    LOG_LEVEL_INFO,
    /** \brief
     *  The "debug" level.
     * 
     *  Designates lower priority information.
     */
    LOG_LEVEL_DEBUG,
    /** \brief
     *  The "trace" level.
     * 
     *  Designates very low priority, often extremely verbose, information.
     */
    LOG_LEVEL_TRACE,
}
#ifdef DOXYGEN
LogLevel_t
#endif
;

typedef struct {

    LogLevel_t level;

    slice_raw_uint8_t target;

    char * message;

} LogRecord_t;

typedef struct {

    void * env_ptr;

    RuneResult_t * (*call)(void *, LogRecord_t);

    void (*free)(void *);

} BoxDynFnMut1_RuneResult_ptr_LogRecord_t;

/** \brief
 *  Set the closure to be called when the Rune emits log messages.
 */
void rune_image_set_log (
    RunicosBaseImage_t * image,
    BoxDynFnMut1_RuneResult_ptr_LogRecord_t factory);

/** \remark Has the same ABI as `uint32_t` **/
#ifdef DOXYGEN
typedef enum CapabilityType
#else
typedef uint32_t CapabilityType_t; enum
#endif
{
    /** . */
    CAPABILITY_TYPE_RAND = 1,
    /** . */
    CAPABILITY_TYPE_SOUND = 2,
    /** . */
    CAPABILITY_TYPE_ACCEL = 3,
    /** . */
    CAPABILITY_TYPE_IMAGE = 4,
    /** . */
    CAPABILITY_TYPE_RAW = 5,
}
#ifdef DOXYGEN
CapabilityType_t
#endif
;

typedef struct {

    void * env_ptr;

    CapabilityResult_t * (*call)(void *);

    void (*free)(void *);

} BoxDynFnMut0_CapabilityResult_ptr_t;

void rune_image_set_capability_handler (
    RunicosBaseImage_t * image,
    CapabilityType_t capability,
    BoxDynFnMut0_CapabilityResult_ptr_t factory);

typedef struct {

    void * env_ptr;

    ModelResult_t * (*call)(void *, slice_raw_uint8_t);

    void (*free)(void *);

} BoxDynFnMut1_ModelResult_ptr_slice_raw_uint8_t;

/** \brief
 *  Register a function for generating models with the specified mimetype.
 * 
 *  Note: TensorFlow Lite models have a mimetype of "application/tflite-model".
 */
void rune_image_register_model_handler (
    RunicosBaseImage_t * image,
    char const * mimetype,
    BoxDynFnMut1_ModelResult_ptr_slice_raw_uint8_t factory);

char const * rune_log_level_name (
    LogLevel_t level);

/** \brief
 * Create a new `RuneResult` containing the success value.
 */
RuneResult_t * rune_result_RuneResult_new_ok (
    uint8_t value);

/** \brief
 * Create a new `RuneResult` containing the error value.
 */
RuneResult_t * rune_result_RuneResult_new_err (
    Error_t * error);

/** \brief
 * Check if the result contains a `u8`.
 */
bool rune_result_RuneResult_is_ok (
    RuneResult_t const * result);

/** \brief
 * Check if the result contains a `BoxedError`.
 */
bool rune_result_RuneResult_is_err (
    RuneResult_t const * result);

/** \brief
 * Free the `RuneResult` after you are done with it.
 */
void rune_result_RuneResult_free (
    RuneResult_t * result);

/** \brief
 * Get a reference to the `u8` in this `RuneResult`, or `null` if not present.
 */
uint8_t const * rune_result_RuneResult_get_ok (
    RuneResult_t const * result);

/** \brief
 * Get a reference to the `BoxedError` in this `RuneResult`, or `null` if not present.
 */
Error_t * const * rune_result_RuneResult_get_err (
    RuneResult_t const * result);

/** \brief
 * Extract the `u8`, freeing the `RuneResult` and crashing if it actually contains a `BoxedError`.
 */
uint8_t rune_result_RuneResult_take_ok (
    RuneResult_t * result);

/** \brief
 * Extract the `BoxedError`, freeing the `RuneResult` and crashing if it actually contains a `u8`.
 */
Error_t * rune_result_RuneResult_take_err (
    RuneResult_t * result);

/** \brief
 *  `&'lt [T]` but with a guaranteed `#[repr(C)]` layout.
 * 
 *  # C layout (for some given type T)
 * 
 *  ```c
 *  typedef struct {
 *      // Cannot be NULL
 *      T * ptr;
 *      size_t len;
 *  } slice_T;
 *  ```
 * 
 *  # Nullable pointer?
 * 
 *  If you want to support the above typedef, but where the `ptr` field is
 *  allowed to be `NULL` (with the contents of `len` then being undefined)
 *  use the `Option< slice_ptr<_> >` type.
 */
typedef struct {

    uint8_t const * ptr;

    size_t len;

} slice_ref_uint8_t;

/** \brief
 *  The version of Rune this library was compiled against.
 * 
 *  This will return something like `"rune-native v0.1.0 built with
 *  rustc 1.54.0-nightly (1c6868aa2 2021-05-27) at 2021-07-08 09:12:58Z"`.
 */
slice_ref_uint8_t rune_version (void);

/** \brief
 *  Free a string that was allocated by this library.
 */
void rune_string_free (
    char * string);

/** \brief
 *  Construct a new error.
 */
Error_t * rune_error_new (
    char const * msg);

/** \brief
 *  Free the error once you are done with it.
 */
void rune_error_free (
    Error_t * e);

/** \brief
 *  Return a newly allocated string containing the error's backtrace.
 * 
 *  Note: this string must be freed using [`rune_string_free()`].
 */
char * rune_error_backtrace (
    Error_t const * error);

/** \brief
 *  Return a newly allocated string describing the error.
 * 
 *  Note: this string must be freed using [`rune_string_free()`].
 */
char * rune_error_to_string (
    Error_t const * error);

/** \brief
 *  Return a newly allocated string describing the error and any errors that
 *  may have caused it.
 * 
 *  This will also contain a backtrace if the `RUST_BACKTRACE` environment
 *  variable is set.
 * 
 *  Note: this string must be freed using [`rune_string_free()`].
 */
char * rune_error_to_string_verbose (
    Error_t const * error);


#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* _RUST_RUNE_NATIVE_ */
